# Status Saver

A small Android app that shows the WhatsApp statuses you've already viewed (images and videos) and saves them to your gallery.

## How it works
- WhatsApp keeps statuses you've viewed in a hidden folder: `Android/media/com.whatsapp/WhatsApp/Media/.Statuses`.
- On first launch, tap **Grant access**. The folder picker opens right at that folder: tap **Use this folder**, then **Allow**. (Picking the `WhatsApp` or `Media` folder also works — the app finds `.Statuses` inside.)
- Browse the **Images** and **Videos** tabs. Tap a tile to view it full screen, or the download button to save it.
- Saved files go to `Pictures/StatusSaver` and `Movies/StatusSaver`, so they show up in your gallery.
- Statuses expire after 24 hours in WhatsApp, so save the ones you want before then. View new statuses in WhatsApp, come back, and tap Refresh.

Requires Android 8.0 or newer.

## Build the APK

### Option A: GitHub (no computer software needed)
1. Create a new GitHub repository and push this folder to it.
2. The included workflow (`.github/workflows/build.yml`) builds automatically on every push.
3. Open the repo's **Actions** tab → the latest "Build APK" run → download **StatusSaver-apk**.
4. Unzip it, copy `app-debug.apk` to your phone, and open it (allow "Install unknown apps" when asked).

### Option B: Android Studio
1. Open this folder in Android Studio.
2. Let Gradle sync, then **Build → Build APK(s)**.
3. The APK is at `app/build/outputs/apk/debug/app-debug.apk`.

## Project layout
- `MainActivity.kt` – tabs, grid, folder access
- `ViewerActivity.kt` – full-screen image/video viewer with Save
- `StatusRepository.kt` – reads the status folder through Android's Storage Access Framework
- `MediaSaver.kt` – copies a status into the gallery (MediaStore on Android 10+)
- `StatusAdapter.kt` – grid tiles (thumbnails via Glide)

Only save and share statuses you have permission to keep.
