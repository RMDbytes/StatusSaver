package com.statussaver.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.DocumentsContract
import android.provider.DocumentsContract.Document

/**
 * Reads WhatsApp statuses through the Storage Access Framework.
 * The user grants access once to the ".Statuses" folder; we keep that permission.
 */
object StatusRepository {

    private const val PREFS = "status_saver_prefs"
    private const val KEY_TREE_URI = "tree_uri"
    private const val EXTERNAL_STORAGE_AUTHORITY = "com.android.externalstorage.documents"

    /** Where the folder picker opens, so the user only has to tap "Use this folder". */
    fun initialPickerUri(): Uri {
        return DocumentsContract.buildDocumentUri(
            EXTERNAL_STORAGE_AUTHORITY,
            "primary:Android/media/com.whatsapp/WhatsApp/Media/.Statuses",
        )
    }

    fun savedTreeUri(context: Context): Uri? {
        val stored = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_TREE_URI, null) ?: return null
        val uri = Uri.parse(stored)
        val stillGranted = context.contentResolver.persistedUriPermissions.any {
            it.uri == uri && it.isReadPermission
        }
        return if (stillGranted) uri else null
    }

    /** Persists access to the picked folder. Returns the tree to read statuses from, or null if none found. */
    fun onFolderPicked(context: Context, pickedTree: Uri): Uri? {
        context.contentResolver.takePersistableUriPermission(
            pickedTree, Intent.FLAG_GRANT_READ_URI_PERMISSION,
        )
        // Accept the .Statuses folder itself, or a parent of it (e.g. "WhatsApp" or "Media").
        val treeDocId = DocumentsContract.getTreeDocumentId(pickedTree)
        val statusesDocId = findStatusesDocId(context, pickedTree, treeDocId, depth = 0)
            ?: return null

        // Keep the picked tree URI (that's what the permission is attached to) plus the doc id to read.
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_TREE_URI, pickedTree.toString())
            .putString(KEY_TREE_URI + "_doc", statusesDocId)
            .apply()
        return pickedTree
    }

    private fun statusesDocId(context: Context, treeUri: Uri): String {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_TREE_URI + "_doc", null)
            ?: DocumentsContract.getTreeDocumentId(treeUri)
    }

    private fun findStatusesDocId(context: Context, tree: Uri, docId: String, depth: Int): String? {
        if (docId.trimEnd('/').endsWith(".Statuses")) return docId
        if (depth > 6) return null
        val children = queryChildren(context, tree, docId)
        // A folder full of media is fine too (e.g. WhatsApp Business or a custom location).
        if (children.any { !it.isDir && isMedia(it.name, it.mime) }) return docId
        children.firstOrNull { it.isDir && it.name == ".Statuses" }?.let { return it.docId }
        val order = listOf("WhatsApp", "Media", "com.whatsapp", "media", "Android")
        val dirs = children.filter { it.isDir }.sortedBy { d ->
            order.indexOf(d.name).let { if (it < 0) Int.MAX_VALUE else it }
        }
        for (dir in dirs.filter { it.name in order }) {
            findStatusesDocId(context, tree, dir.docId, depth + 1)?.let { return it }
        }
        return null
    }

    private data class Child(
        val docId: String,
        val name: String,
        val mime: String,
        val lastModified: Long,
    ) {
        val isDir get() = mime == Document.MIME_TYPE_DIR
    }

    private fun queryChildren(context: Context, tree: Uri, parentDocId: String): List<Child> {
        val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(tree, parentDocId)
        val projection = arrayOf(
            Document.COLUMN_DOCUMENT_ID,
            Document.COLUMN_DISPLAY_NAME,
            Document.COLUMN_MIME_TYPE,
            Document.COLUMN_LAST_MODIFIED,
        )
        val result = mutableListOf<Child>()
        try {
            context.contentResolver.query(childrenUri, projection, null, null, null)?.use { c ->
                while (c.moveToNext()) {
                    result += Child(
                        docId = c.getString(0),
                        name = c.getString(1) ?: "",
                        mime = c.getString(2) ?: "",
                        lastModified = if (c.isNull(3)) 0L else c.getLong(3),
                    )
                }
            }
        } catch (e: Exception) {
            // Permission revoked or folder deleted; treat as empty.
        }
        return result
    }

    /** Lists all image and video statuses, newest first. Call off the main thread. */
    fun loadStatuses(context: Context, treeUri: Uri): List<StatusItem> {
        val parentId = statusesDocId(context, treeUri)
        return queryChildren(context, treeUri, parentId)
            .filter { !it.isDir && isMedia(it.name, it.mime) }
            .map { child ->
                val video = isVideo(child.name, child.mime)
                StatusItem(
                    uri = DocumentsContract.buildDocumentUriUsingTree(treeUri, child.docId),
                    name = child.name,
                    mimeType = child.mime.ifBlank { if (video) "video/mp4" else "image/jpeg" },
                    isVideo = video,
                    lastModified = child.lastModified,
                )
            }
            .sortedByDescending { it.lastModified }
    }

    private val imageExt = setOf("jpg", "jpeg", "png", "webp", "gif")
    private val videoExt = setOf("mp4", "3gp", "mkv", "webm", "mov")

    private fun ext(name: String) = name.substringAfterLast('.', "").lowercase()

    private fun isVideo(name: String, mime: String) =
        mime.startsWith("video/") || ext(name) in videoExt

    private fun isMedia(name: String, mime: String): Boolean {
        if (name.startsWith(".")) return false // e.g. .nomedia
        return mime.startsWith("image/") || mime.startsWith("video/") ||
            ext(name) in imageExt || ext(name) in videoExt
    }
}
