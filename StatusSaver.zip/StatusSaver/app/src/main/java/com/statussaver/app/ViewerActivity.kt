package com.statussaver.app

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.MediaController
import android.widget.Toast
import android.widget.VideoView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.bumptech.glide.Glide
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton
import kotlinx.coroutines.launch

class ViewerActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_URI = "uri"
        const val EXTRA_NAME = "name"
        const val EXTRA_MIME = "mime"
        const val EXTRA_IS_VIDEO = "is_video"
    }

    private lateinit var item: StatusItem
    private var videoView: VideoView? = null

    private val writePermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) doSave() else toast(getString(R.string.storage_permission_needed))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_viewer)

        val uriString = intent.getStringExtra(EXTRA_URI)
        if (uriString == null) { finish(); return }
        val isVideo = intent.getBooleanExtra(EXTRA_IS_VIDEO, false)
        item = StatusItem(
            uri = Uri.parse(uriString),
            name = intent.getStringExtra(EXTRA_NAME) ?: "status",
            mimeType = intent.getStringExtra(EXTRA_MIME) ?: if (isVideo) "video/mp4" else "image/jpeg",
            isVideo = isVideo,
            lastModified = 0L,
        )

        if (isVideo) {
            val video = findViewById<VideoView>(R.id.video)
            videoView = video
            video.visibility = View.VISIBLE
            val controller = MediaController(this)
            controller.setAnchorView(video)
            video.setMediaController(controller)
            video.setVideoURI(item.uri)
            video.setOnPreparedListener { it.isLooping = true; video.start() }
        } else {
            val image = findViewById<ImageView>(R.id.image)
            image.visibility = View.VISIBLE
            Glide.with(this).load(item.uri).fitCenter().into(image)
        }

        findViewById<ExtendedFloatingActionButton>(R.id.save_fab).setOnClickListener { save() }
    }

    override fun onPause() {
        super.onPause()
        videoView?.pause()
    }

    override fun onResume() {
        super.onResume()
        videoView?.start()
    }

    private fun save() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
            != PackageManager.PERMISSION_GRANTED
        ) {
            writePermission.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        } else {
            doSave()
        }
    }

    private fun doSave() {
        lifecycleScope.launch {
            val ok = MediaSaver.save(this@ViewerActivity, item)
            toast(getString(if (ok) R.string.saved else R.string.save_failed))
        }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
