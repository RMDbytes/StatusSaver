package com.statussaver.app

import android.content.ContentValues
import android.content.Context
import android.media.MediaScannerConnection
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/** Copies a status into the phone's gallery (Pictures/StatusSaver or Movies/StatusSaver). */
object MediaSaver {

    private const val FOLDER = "StatusSaver"

    suspend fun save(context: Context, item: StatusItem): Boolean = withContext(Dispatchers.IO) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) saveWithMediaStore(context, item)
            else saveLegacy(context, item)
        } catch (e: Exception) {
            false
        }
    }

    private fun saveWithMediaStore(context: Context, item: StatusItem): Boolean {
        val resolver = context.contentResolver
        val collection = if (item.isVideo) {
            MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        } else {
            MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        }
        val baseDir = if (item.isVideo) Environment.DIRECTORY_MOVIES else Environment.DIRECTORY_PICTURES
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, item.name)
            put(MediaStore.MediaColumns.MIME_TYPE, item.mimeType)
            put(MediaStore.MediaColumns.RELATIVE_PATH, "$baseDir/$FOLDER")
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val dest = resolver.insert(collection, values) ?: return false
        try {
            val input = resolver.openInputStream(item.uri) ?: throw IllegalStateException("no input")
            input.use { src ->
                val output = resolver.openOutputStream(dest) ?: throw IllegalStateException("no output")
                output.use { src.copyTo(it) }
            }
        } catch (e: Exception) {
            resolver.delete(dest, null, null)
            return false
        }
        values.clear()
        values.put(MediaStore.MediaColumns.IS_PENDING, 0)
        resolver.update(dest, values, null, null)
        return true
    }

    @Suppress("DEPRECATION")
    private fun saveLegacy(context: Context, item: StatusItem): Boolean {
        val baseDir = if (item.isVideo) Environment.DIRECTORY_MOVIES else Environment.DIRECTORY_PICTURES
        val dir = File(Environment.getExternalStoragePublicDirectory(baseDir), FOLDER)
        if (!dir.exists() && !dir.mkdirs()) return false
        val file = File(dir, item.name)
        val input = context.contentResolver.openInputStream(item.uri) ?: return false
        input.use { src -> file.outputStream().use { src.copyTo(it) } }
        MediaScannerConnection.scanFile(context, arrayOf(file.absolutePath), arrayOf(item.mimeType), null)
        return true
    }
}
