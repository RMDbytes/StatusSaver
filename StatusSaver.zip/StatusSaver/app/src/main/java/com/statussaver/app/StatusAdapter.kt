package com.statussaver.app

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide

class StatusAdapter(
    private val onOpen: (StatusItem) -> Unit,
    private val onSave: (StatusItem) -> Unit,
) : ListAdapter<StatusItem, StatusAdapter.Holder>(Diff) {

    class Holder(view: View) : RecyclerView.ViewHolder(view) {
        val thumb: ImageView = view.findViewById(R.id.thumb)
        val play: ImageView = view.findViewById(R.id.play_icon)
        val save: ImageView = view.findViewById(R.id.save_button)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_status, parent, false)
        return Holder(view)
    }

    override fun onBindViewHolder(holder: Holder, position: Int) {
        val item = getItem(position)
        Glide.with(holder.thumb)
            .load(item.uri)
            .centerCrop()
            .into(holder.thumb)
        holder.play.visibility = if (item.isVideo) View.VISIBLE else View.GONE
        holder.itemView.setOnClickListener { onOpen(item) }
        holder.save.setOnClickListener { onSave(item) }
    }

    private object Diff : DiffUtil.ItemCallback<StatusItem>() {
        override fun areItemsTheSame(a: StatusItem, b: StatusItem) = a.uri == b.uri
        override fun areContentsTheSame(a: StatusItem, b: StatusItem) = a == b
    }
}
