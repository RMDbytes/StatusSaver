package com.statussaver.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.tabs.TabLayout
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private lateinit var tabs: TabLayout
    private lateinit var recycler: RecyclerView
    private lateinit var progress: ProgressBar
    private lateinit var emptyState: LinearLayout
    private lateinit var emptyText: TextView
    private lateinit var grantButton: Button
    private lateinit var adapter: StatusAdapter

    private var allStatuses: List<StatusItem> = emptyList()
    private var pendingSave: StatusItem? = null

    private val pickFolder = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) handlePickedFolder(uri)
    }

    private val writePermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        val item = pendingSave
        pendingSave = null
        if (granted && item != null) save(item)
        else if (!granted) toast(getString(R.string.storage_permission_needed))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val toolbar = findViewById<MaterialToolbar>(R.id.toolbar)
        tabs = findViewById(R.id.tabs)
        recycler = findViewById(R.id.recycler)
        progress = findViewById(R.id.progress)
        emptyState = findViewById(R.id.empty_state)
        emptyText = findViewById(R.id.empty_text)
        grantButton = findViewById(R.id.grant_button)

        toolbar.inflateMenu(R.menu.main_menu)
        toolbar.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                R.id.action_refresh -> { reload(); true }
                R.id.action_change_folder -> { openPicker(); true }
                else -> false
            }
        }

        tabs.addTab(tabs.newTab().setText(R.string.tab_images))
        tabs.addTab(tabs.newTab().setText(R.string.tab_videos))
        tabs.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab) = showCurrentTab()
            override fun onTabUnselected(tab: TabLayout.Tab) {}
            override fun onTabReselected(tab: TabLayout.Tab) { recycler.smoothScrollToPosition(0) }
        })

        adapter = StatusAdapter(onOpen = ::openViewer, onSave = ::save)
        recycler.layoutManager = GridLayoutManager(this, 3)
        recycler.adapter = adapter

        grantButton.setOnClickListener { openPicker() }
    }

    override fun onResume() {
        super.onResume()
        reload() // pick up statuses viewed while the app was in the background
    }

    private fun openPicker() {
        try {
            pickFolder.launch(StatusRepository.initialPickerUri())
        } catch (e: Exception) {
            pickFolder.launch(null)
        }
    }

    private fun handlePickedFolder(uri: Uri) {
        lifecycleScope.launch {
            progress.visibility = View.VISIBLE
            val tree = withContext(Dispatchers.IO) {
                try { StatusRepository.onFolderPicked(this@MainActivity, uri) } catch (e: Exception) { null }
            }
            progress.visibility = View.GONE
            if (tree == null) toast(getString(R.string.wrong_folder)) else reload()
        }
    }

    private fun reload() {
        val tree = StatusRepository.savedTreeUri(this)
        if (tree == null) {
            allStatuses = emptyList()
            adapter.submitList(emptyList())
            emptyText.setText(R.string.need_access)
            grantButton.visibility = View.VISIBLE
            emptyState.visibility = View.VISIBLE
            return
        }
        lifecycleScope.launch {
            if (allStatuses.isEmpty()) progress.visibility = View.VISIBLE
            val items = withContext(Dispatchers.IO) {
                StatusRepository.loadStatuses(this@MainActivity, tree)
            }
            progress.visibility = View.GONE
            allStatuses = items
            showCurrentTab()
        }
    }

    private fun showCurrentTab() {
        if (StatusRepository.savedTreeUri(this) == null) return
        val videos = tabs.selectedTabPosition == 1
        val list = allStatuses.filter { it.isVideo == videos }
        adapter.submitList(list)
        grantButton.visibility = View.GONE
        emptyText.setText(if (videos) R.string.no_videos else R.string.no_images)
        emptyState.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun openViewer(item: StatusItem) {
        startActivity(
            Intent(this, ViewerActivity::class.java)
                .putExtra(ViewerActivity.EXTRA_URI, item.uri.toString())
                .putExtra(ViewerActivity.EXTRA_NAME, item.name)
                .putExtra(ViewerActivity.EXTRA_MIME, item.mimeType)
                .putExtra(ViewerActivity.EXTRA_IS_VIDEO, item.isVideo)
        )
    }

    private fun save(item: StatusItem) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
            != PackageManager.PERMISSION_GRANTED
        ) {
            pendingSave = item
            writePermission.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
            return
        }
        lifecycleScope.launch {
            val ok = MediaSaver.save(this@MainActivity, item)
            toast(getString(if (ok) R.string.saved else R.string.save_failed))
        }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
