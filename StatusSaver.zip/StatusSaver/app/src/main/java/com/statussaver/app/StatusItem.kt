package com.statussaver.app

import android.net.Uri

data class StatusItem(
    val uri: Uri,
    val name: String,
    val mimeType: String,
    val isVideo: Boolean,
    val lastModified: Long,
)
